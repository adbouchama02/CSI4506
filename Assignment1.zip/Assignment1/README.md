# CSI 4106 Introduction to Artificial Intelligence

## Assignment 1: Data Preparation

Maternal Health Risk: 
- Number of samples: 1013, Number of attributes: 6, Number of classes: 3 (risk level – high, medium, low)
- [archive.ics.uci.edu/dataset/863/maternal+health+risk](https://archive.ics.uci.edu/dataset/863/maternal+health+risk) 
